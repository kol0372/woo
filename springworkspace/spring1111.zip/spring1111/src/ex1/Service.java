package ex1;

public interface Service {
	
	public String print();
	public String call();
	public String moniter();

}
