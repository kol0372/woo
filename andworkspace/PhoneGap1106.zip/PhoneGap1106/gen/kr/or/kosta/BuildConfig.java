/** Automatically generated file. DO NOT MODIFY */
package kr.or.kosta;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}